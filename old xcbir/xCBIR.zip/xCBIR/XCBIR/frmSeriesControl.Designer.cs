namespace XCBIR
{
    partial class frmSeriesControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSeriesControl));
            PureComponents.ActionSet.Controls.ActionScreenTip actionScreenTip1 = new PureComponents.ActionSet.Controls.ActionScreenTip();
            PureComponents.EntrySet.Controls.LabelStyle labelStyle1 = new PureComponents.EntrySet.Controls.LabelStyle();
            PureComponents.EntrySet.Controls.LabelStyle labelStyle2 = new PureComponents.EntrySet.Controls.LabelStyle();
            PureComponents.EntrySet.Lists.MultiListItem multiListItem1 = new PureComponents.EntrySet.Lists.MultiListItem();
            PureComponents.EntrySet.Lists.MultiListFlag multiListFlag1 = new PureComponents.EntrySet.Lists.MultiListFlag();
            PureComponents.EntrySet.Lists.MultiListItemStyle multiListItemStyle1 = new PureComponents.EntrySet.Lists.MultiListItemStyle();
            PureComponents.EntrySet.Lists.MultiListItem multiListItem2 = new PureComponents.EntrySet.Lists.MultiListItem();
            PureComponents.EntrySet.Lists.MultiListFlag multiListFlag2 = new PureComponents.EntrySet.Lists.MultiListFlag();
            PureComponents.EntrySet.Lists.MultiListItemStyle multiListItemStyle2 = new PureComponents.EntrySet.Lists.MultiListItemStyle();
            PureComponents.EntrySet.Lists.MultiListItem multiListItem3 = new PureComponents.EntrySet.Lists.MultiListItem();
            PureComponents.EntrySet.Lists.MultiListFlag multiListFlag3 = new PureComponents.EntrySet.Lists.MultiListFlag();
            PureComponents.EntrySet.Lists.MultiListItemStyle multiListItemStyle3 = new PureComponents.EntrySet.Lists.MultiListItemStyle();
            PureComponents.EntrySet.Lists.MultiListStyle multiListStyle1 = new PureComponents.EntrySet.Lists.MultiListStyle();
            PureComponents.EntrySet.Lists.MultiListActionItemStyle multiListActionItemStyle1 = new PureComponents.EntrySet.Lists.MultiListActionItemStyle();
            PureComponents.EntrySet.Lists.MultiListBackgroundStyle multiListBackgroundStyle1 = new PureComponents.EntrySet.Lists.MultiListBackgroundStyle();
            PureComponents.EntrySet.Lists.MultiListListStyle multiListListStyle1 = new PureComponents.EntrySet.Lists.MultiListListStyle();
            PureComponents.ActionSet.Controls.ActionScreenTip actionScreenTip2 = new PureComponents.ActionSet.Controls.ActionScreenTip();
            PureComponents.ActionSet.Controls.ActionScreenTip actionScreenTip3 = new PureComponents.ActionSet.Controls.ActionScreenTip();
            PureComponents.ActionSet.Controls.ActionScreenTip actionScreenTip4 = new PureComponents.ActionSet.Controls.ActionScreenTip();
            PureComponents.ActionSet.Controls.ActionScreenTip actionScreenTip5 = new PureComponents.ActionSet.Controls.ActionScreenTip();
            PureComponents.EntrySet.Lists.PictureListStyle pictureListStyle1 = new PureComponents.EntrySet.Lists.PictureListStyle();
            PureComponents.EntrySet.Lists.PictureListBackgroundStyle pictureListBackgroundStyle1 = new PureComponents.EntrySet.Lists.PictureListBackgroundStyle();
            PureComponents.EntrySet.Lists.PictureListCategoryStyle pictureListCategoryStyle1 = new PureComponents.EntrySet.Lists.PictureListCategoryStyle();
            PureComponents.EntrySet.Lists.PictureListListStyle pictureListListStyle1 = new PureComponents.EntrySet.Lists.PictureListListStyle();
            PureComponents.EntrySet.Lists.PictureListItemSize pictureListItemSize1 = new PureComponents.EntrySet.Lists.PictureListItemSize();
            PureComponents.EntrySet.Indent indent1 = new PureComponents.EntrySet.Indent();
            PureComponents.EntrySet.Controls.ScreenTip screenTip1 = new PureComponents.EntrySet.Controls.ScreenTip();
            PureComponents.EntrySet.Controls.StickyLabel stickyLabel1 = new PureComponents.EntrySet.Controls.StickyLabel();
            PureComponents.EntrySet.Controls.RichEditBoxStyle richEditBoxStyle1 = new PureComponents.EntrySet.Controls.RichEditBoxStyle();
            this.rbnFrmSerControl = new PureComponents.ActionSet.RibbonUI.RibbonForm();
            this.ribbonScrollablePanel1 = new PureComponents.ActionSet.RibbonUI.RibbonScrollablePanel();
            this.ribbonPanel1 = new PureComponents.ActionSet.RibbonUI.RibbonPanel();
            this.rbnBtnAddCat = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnAddPat = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnUnremove = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnTemp = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnCancel = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnDone = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnDelAll = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.lblSeriesID = new PureComponents.EntrySet.Controls.Label();
            this.lblPatiant = new PureComponents.EntrySet.Controls.Label();
            this.mListCats = new PureComponents.EntrySet.Lists.MultiList();
            this.rbnCboPatiant = new PureComponents.ActionSet.RibbonUI.RibbonComboBox();
            this.rbnBtnManipulate = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnNotes = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnRemoveImage = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.rbnBtnAddImage = new PureComponents.ActionSet.RibbonUI.RibbonButton();
            this.picLstSerImage = new PureComponents.EntrySet.Lists.PictureList();
            this.picQView = new System.Windows.Forms.PictureBox();
            this.rbnTxtNotes = new PureComponents.EntrySet.Controls.RichEditBox();
            this.proBarOpr = new PureComponents.EntrySet.Controls.SystemProgressBar();
            this.rbnCboSeriesID = new PureComponents.ActionSet.RibbonUI.RibbonComboBox();
            this.rbnTxtSeriesID = new PureComponents.ActionSet.RibbonUI.RibbonTextBox();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.rbnFrmSerControl)).BeginInit();
            this.rbnFrmSerControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonScrollablePanel1)).BeginInit();
            this.ribbonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lblSeriesID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPatiant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mListCats)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLstSerImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbnTxtNotes)).BeginInit();
            this.SuspendLayout();
            // 
            // rbnFrmSerControl
            // 
            this.rbnFrmSerControl.ClientContainer = this.ribbonScrollablePanel1;
            this.rbnFrmSerControl.Controls.Add(this.ribbonScrollablePanel1);
            this.rbnFrmSerControl.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnFrmSerControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rbnFrmSerControl.Icon = ((System.Drawing.Image)(resources.GetObject("rbnFrmSerControl.Icon")));
            this.rbnFrmSerControl.Location = new System.Drawing.Point(0, 0);
            this.rbnFrmSerControl.Name = "rbnFrmSerControl";
            this.rbnFrmSerControl.ShowButtonBar = false;
            this.rbnFrmSerControl.ShowMaximizeButton = false;
            this.rbnFrmSerControl.ShowMinimizeButton = false;
            this.rbnFrmSerControl.ShowResizeHandler = false;
            this.rbnFrmSerControl.Size = new System.Drawing.Size(631, 604);
            this.rbnFrmSerControl.TabIndex = 0;
            this.rbnFrmSerControl.Text = "[Opr] Series";
            // 
            // ribbonScrollablePanel1
            // 
            this.ribbonScrollablePanel1.BackColor = System.Drawing.Color.Transparent;
            this.ribbonScrollablePanel1.FormBackground = PureComponents.ActionSet.RibbonUI.RibbonBackground.Curvature1;
            this.ribbonScrollablePanel1.InnerControl = this.ribbonPanel1;
            this.ribbonScrollablePanel1.Location = new System.Drawing.Point(1, 28);
            this.ribbonScrollablePanel1.Name = "ribbonScrollablePanel1";
            this.ribbonScrollablePanel1.Size = new System.Drawing.Size(628, 573);
            this.ribbonScrollablePanel1.TabIndex = 1;
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.BackColor = System.Drawing.Color.Transparent;
            this.ribbonPanel1.Controls.Add(this.rbnBtnAddCat);
            this.ribbonPanel1.Controls.Add(this.rbnBtnAddPat);
            this.ribbonPanel1.Controls.Add(this.rbnBtnUnremove);
            this.ribbonPanel1.Controls.Add(this.rbnBtnTemp);
            this.ribbonPanel1.Controls.Add(this.rbnBtnCancel);
            this.ribbonPanel1.Controls.Add(this.rbnBtnDone);
            this.ribbonPanel1.Controls.Add(this.rbnBtnDelAll);
            this.ribbonPanel1.Controls.Add(this.lblSeriesID);
            this.ribbonPanel1.Controls.Add(this.lblPatiant);
            this.ribbonPanel1.Controls.Add(this.mListCats);
            this.ribbonPanel1.Controls.Add(this.rbnCboPatiant);
            this.ribbonPanel1.Controls.Add(this.rbnBtnManipulate);
            this.ribbonPanel1.Controls.Add(this.rbnBtnNotes);
            this.ribbonPanel1.Controls.Add(this.rbnBtnRemoveImage);
            this.ribbonPanel1.Controls.Add(this.rbnBtnAddImage);
            this.ribbonPanel1.Controls.Add(this.picLstSerImage);
            this.ribbonPanel1.Controls.Add(this.picQView);
            this.ribbonPanel1.Controls.Add(this.rbnTxtNotes);
            this.ribbonPanel1.Controls.Add(this.proBarOpr);
            this.ribbonPanel1.Controls.Add(this.rbnCboSeriesID);
            this.ribbonPanel1.Controls.Add(this.rbnTxtSeriesID);
            this.ribbonPanel1.FormBackground = PureComponents.ActionSet.RibbonUI.RibbonBackground.Curvature1;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 0);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Size = new System.Drawing.Size(628, 573);
            this.ribbonPanel1.TabIndex = 0;
            // 
            // rbnBtnAddCat
            // 
            this.rbnBtnAddCat.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnAddCat.Image = null;
            this.rbnBtnAddCat.Location = new System.Drawing.Point(536, 103);
            this.rbnBtnAddCat.Name = "rbnBtnAddCat";
            this.rbnBtnAddCat.Size = new System.Drawing.Size(77, 20);
            this.rbnBtnAddCat.TabIndex = 19;
            this.rbnBtnAddCat.Text = "Add Category";
            this.rbnBtnAddCat.Click += new System.EventHandler(this.rbnBtnAddCat_Click);
            // 
            // rbnBtnAddPat
            // 
            this.rbnBtnAddPat.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnAddPat.Image = null;
            this.rbnBtnAddPat.Location = new System.Drawing.Point(536, 45);
            this.rbnBtnAddPat.Name = "rbnBtnAddPat";
            this.rbnBtnAddPat.Size = new System.Drawing.Size(77, 21);
            this.rbnBtnAddPat.TabIndex = 19;
            this.rbnBtnAddPat.Text = "Add Patiant";
            this.rbnBtnAddPat.Click += new System.EventHandler(this.rbnBtnAddPat_Click);
            // 
            // rbnBtnUnremove
            // 
            this.rbnBtnUnremove.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnUnremove.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnUnremove.Image")));
            this.rbnBtnUnremove.Location = new System.Drawing.Point(349, 534);
            this.rbnBtnUnremove.Name = "rbnBtnUnremove";
            actionScreenTip1.Active = true;
            actionScreenTip1.Description = "Undoes removal of selected removed item";
            actionScreenTip1.Image = null;
            actionScreenTip1.Text = "Undo Remove";
            this.rbnBtnUnremove.ScreenTip = actionScreenTip1;
            this.rbnBtnUnremove.Size = new System.Drawing.Size(84, 23);
            this.rbnBtnUnremove.TabIndex = 9;
            this.rbnBtnUnremove.Text = "Un-remove";
            this.rbnBtnUnremove.Visible = false;
            this.rbnBtnUnremove.Click += new System.EventHandler(this.rbnBtnUnremove_Click);
            // 
            // rbnBtnTemp
            // 
            this.rbnBtnTemp.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnTemp.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnTemp.Image")));
            this.rbnBtnTemp.Location = new System.Drawing.Point(161, 215);
            this.rbnBtnTemp.Name = "rbnBtnTemp";
            this.rbnBtnTemp.Size = new System.Drawing.Size(148, 12);
            this.rbnBtnTemp.TabIndex = 1;
            this.rbnBtnTemp.Text = "ribbonButton1";
            this.rbnBtnTemp.Visible = false;
            // 
            // rbnBtnCancel
            // 
            this.rbnBtnCancel.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnCancel.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnCancel.Image")));
            this.rbnBtnCancel.Location = new System.Drawing.Point(455, 534);
            this.rbnBtnCancel.Name = "rbnBtnCancel";
            this.rbnBtnCancel.Size = new System.Drawing.Size(75, 23);
            this.rbnBtnCancel.TabIndex = 10;
            this.rbnBtnCancel.Text = "Cancel";
            this.rbnBtnCancel.Click += new System.EventHandler(this.rbnBtnCancel_Click);
            // 
            // rbnBtnDone
            // 
            this.rbnBtnDone.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnDone.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnDone.Image")));
            this.rbnBtnDone.Location = new System.Drawing.Point(536, 534);
            this.rbnBtnDone.Name = "rbnBtnDone";
            this.rbnBtnDone.Size = new System.Drawing.Size(75, 23);
            this.rbnBtnDone.TabIndex = 11;
            this.rbnBtnDone.Text = "[Opr]";
            this.rbnBtnDone.Click += new System.EventHandler(this.rbnBtnDone_Click);
            // 
            // rbnBtnDelAll
            // 
            this.rbnBtnDelAll.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnDelAll.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnDelAll.Image")));
            this.rbnBtnDelAll.Location = new System.Drawing.Point(205, 534);
            this.rbnBtnDelAll.Name = "rbnBtnDelAll";
            this.rbnBtnDelAll.Size = new System.Drawing.Size(86, 23);
            this.rbnBtnDelAll.TabIndex = 7;
            this.rbnBtnDelAll.Text = "Remove All";
            this.rbnBtnDelAll.Click += new System.EventHandler(this.rbnBtnDelAll_Click);
            // 
            // lblSeriesID
            // 
            this.lblSeriesID.BackColor = System.Drawing.Color.Transparent;
            this.lblSeriesID.ForeColor = System.Drawing.Color.Black;
            this.lblSeriesID.Location = new System.Drawing.Point(403, 72);
            this.lblSeriesID.Name = "lblSeriesID";
            this.lblSeriesID.Size = new System.Drawing.Size(115, 23);
            labelStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblSeriesID.Style = labelStyle1;
            this.lblSeriesID.TabIndex = 13;
            this.lblSeriesID.TabStop = false;
            this.lblSeriesID.Text = "Series ID";
            // 
            // lblPatiant
            // 
            this.lblPatiant.BackColor = System.Drawing.Color.Transparent;
            this.lblPatiant.ForeColor = System.Drawing.Color.Black;
            this.lblPatiant.Location = new System.Drawing.Point(403, 15);
            this.lblPatiant.Name = "lblPatiant";
            this.lblPatiant.Size = new System.Drawing.Size(115, 23);
            labelStyle2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.lblPatiant.Style = labelStyle2;
            this.lblPatiant.TabIndex = 12;
            this.lblPatiant.TabStop = false;
            this.lblPatiant.Text = "Patiant ID/Name";
            // 
            // mListCats
            // 
            multiListItem1.AllowSelect = false;
            multiListItem1.Description = null;
            multiListItem1.DividerColor = System.Drawing.Color.DarkGray;
            multiListItem1.Flag = multiListFlag1;
            multiListItem1.Image = null;
            multiListItem1.ShowDivider = true;
            multiListItem1.Style = multiListItemStyle1;
            multiListItem1.Text = "Action Item";
            this.mListCats.ActionItem = multiListItem1;
            multiListItem2.Description = "Ahmad";
            multiListItem2.Flag = multiListFlag2;
            multiListItem2.Image = null;
            multiListItemStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(75)))), ((int)(((byte)(26)))));
            multiListItem2.Style = multiListItemStyle2;
            multiListItem2.Text = "Hajjar";
            multiListItem3.CheckState = System.Windows.Forms.CheckState.Checked;
            multiListItem3.Description = "Osama";
            multiListItem3.Flag = multiListFlag3;
            multiListItem3.Image = null;
            multiListItem3.Style = multiListItemStyle3;
            multiListItem3.Text = "Al Khatib";
            this.mListCats.Items.AddRange(new PureComponents.EntrySet.Lists.MultiListItem[] {
            multiListItem2,
            multiListItem3});
            this.mListCats.Location = new System.Drawing.Point(403, 129);
            this.mListCats.Name = "mListCats";
            this.mListCats.SelectedValue = null;
            this.mListCats.ShowFlag = false;
            this.mListCats.Size = new System.Drawing.Size(209, 271);
            multiListActionItemStyle1.SelectionFillStyle = PureComponents.EntrySet.FillStyle.VerticalFading;
            multiListActionItemStyle1.SelectionShape = PureComponents.EntrySet.Shape.Vista;
            multiListStyle1.ActionItemStyle = multiListActionItemStyle1;
            multiListStyle1.BackgroundStyle = multiListBackgroundStyle1;
            multiListStyle1.ListStyle = multiListListStyle1;
            this.mListCats.Style = multiListStyle1;
            this.mListCats.TabIndex = 2;
            this.mListCats.ItemChecked += new PureComponents.EntrySet.Lists.MultiList.ItemCheckedEventHandler(this.mListCats_ItemChecked);
            // 
            // rbnCboPatiant
            // 
            this.rbnCboPatiant.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnCboPatiant.Location = new System.Drawing.Point(403, 44);
            this.rbnCboPatiant.Name = "rbnCboPatiant";
            this.rbnCboPatiant.SelectedIndex = -1;
            this.rbnCboPatiant.SelectedItem = null;
            this.rbnCboPatiant.Size = new System.Drawing.Size(130, 22);
            this.rbnCboPatiant.TabIndex = 0;
            this.rbnCboPatiant.Text = "Select Patiant";
            this.rbnCboPatiant.SelectedIndexChanged += new System.EventHandler(this.rbnCboPatiant_SelectedIndexChanged);
            // 
            // rbnBtnManipulate
            // 
            this.rbnBtnManipulate.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnManipulate.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnManipulate.Image")));
            this.rbnBtnManipulate.Location = new System.Drawing.Point(297, 534);
            this.rbnBtnManipulate.Name = "rbnBtnManipulate";
            actionScreenTip2.Active = true;
            actionScreenTip2.Description = "Manipulate the selected image";
            actionScreenTip2.Image = null;
            actionScreenTip2.Text = "ScreenTip";
            this.rbnBtnManipulate.ScreenTip = actionScreenTip2;
            this.rbnBtnManipulate.Size = new System.Drawing.Size(48, 23);
            this.rbnBtnManipulate.TabIndex = 8;
            this.rbnBtnManipulate.Text = "Edit";
            this.rbnBtnManipulate.Click += new System.EventHandler(this.rbnBtnManipulate_Click);
            // 
            // rbnBtnNotes
            // 
            this.rbnBtnNotes.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnNotes.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnNotes.Image")));
            this.rbnBtnNotes.ImageAlign = PureComponents.ActionSet.Common.ImageAlignment.Left;
            this.rbnBtnNotes.Location = new System.Drawing.Point(11, 534);
            this.rbnBtnNotes.Name = "rbnBtnNotes";
            actionScreenTip3.Active = true;
            actionScreenTip3.Description = "Add notes on this series";
            actionScreenTip3.Image = null;
            actionScreenTip3.Text = "ScreenTip";
            this.rbnBtnNotes.ScreenTip = actionScreenTip3;
            this.rbnBtnNotes.Size = new System.Drawing.Size(58, 23);
            this.rbnBtnNotes.TabIndex = 4;
            this.rbnBtnNotes.Tag = "N";
            this.rbnBtnNotes.Text = "Notes";
            this.rbnBtnNotes.Click += new System.EventHandler(this.rbnBtnNotes_Click);
            // 
            // rbnBtnRemoveImage
            // 
            this.rbnBtnRemoveImage.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnRemoveImage.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnRemoveImage.Image")));
            this.rbnBtnRemoveImage.Location = new System.Drawing.Point(129, 534);
            this.rbnBtnRemoveImage.Name = "rbnBtnRemoveImage";
            actionScreenTip4.Active = true;
            actionScreenTip4.Description = "Delete the selected image from the series";
            actionScreenTip4.Image = null;
            actionScreenTip4.Text = "ScreenTip";
            this.rbnBtnRemoveImage.ScreenTip = actionScreenTip4;
            this.rbnBtnRemoveImage.Size = new System.Drawing.Size(70, 23);
            this.rbnBtnRemoveImage.TabIndex = 6;
            this.rbnBtnRemoveImage.Text = "Remove";
            this.rbnBtnRemoveImage.Click += new System.EventHandler(this.rbnBtnRemoveImage_Click);
            // 
            // rbnBtnAddImage
            // 
            this.rbnBtnAddImage.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnBtnAddImage.Image = ((System.Drawing.Image)(resources.GetObject("rbnBtnAddImage.Image")));
            this.rbnBtnAddImage.Location = new System.Drawing.Point(75, 534);
            this.rbnBtnAddImage.Name = "rbnBtnAddImage";
            actionScreenTip5.Active = true;
            actionScreenTip5.Description = "Add a new image to the series";
            actionScreenTip5.Image = null;
            actionScreenTip5.Text = "ScreenTip";
            this.rbnBtnAddImage.ScreenTip = actionScreenTip5;
            this.rbnBtnAddImage.Size = new System.Drawing.Size(48, 23);
            this.rbnBtnAddImage.TabIndex = 5;
            this.rbnBtnAddImage.Text = "Add";
            this.rbnBtnAddImage.Click += new System.EventHandler(this.rbnBtnAddImage_Click);
            // 
            // picLstSerImage
            // 
            this.picLstSerImage.Location = new System.Drawing.Point(11, 406);
            this.picLstSerImage.Name = "picLstSerImage";
            this.picLstSerImage.Size = new System.Drawing.Size(601, 122);
            pictureListStyle1.BackgroundStyle = pictureListBackgroundStyle1;
            pictureListCategoryStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            pictureListCategoryStyle1.FadeColor = System.Drawing.Color.Transparent;
            pictureListCategoryStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            pictureListStyle1.CategoryStyle = pictureListCategoryStyle1;
            indent1.X = 5;
            indent1.Y = 5;
            pictureListItemSize1.Border = indent1;
            pictureListListStyle1.ItemSize = pictureListItemSize1;
            pictureListStyle1.ListStyle = pictureListListStyle1;
            this.picLstSerImage.Style = pictureListStyle1;
            this.picLstSerImage.TabIndex = 4;
            this.picLstSerImage.SelectedIndexChanged += new System.EventHandler(this.picLstSerImage_SelectedIndexChanged);
            // 
            // picQView
            // 
            this.picQView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picQView.Location = new System.Drawing.Point(11, 15);
            this.picQView.Name = "picQView";
            this.picQView.Size = new System.Drawing.Size(385, 385);
            this.picQView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picQView.TabIndex = 3;
            this.picQView.TabStop = false;
            // 
            // rbnTxtNotes
            // 
            this.rbnTxtNotes.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.rbnTxtNotes.Description = null;
            this.rbnTxtNotes.Location = new System.Drawing.Point(11, 493);
            this.rbnTxtNotes.Name = "rbnTxtNotes";
            screenTip1.BackColor = System.Drawing.Color.WhiteSmoke;
            screenTip1.BorderColor = System.Drawing.Color.DarkGray;
            screenTip1.FadeColor = System.Drawing.Color.White;
            screenTip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            screenTip1.ForeColor = System.Drawing.Color.Black;
            this.rbnTxtNotes.ScreenTip = screenTip1;
            this.rbnTxtNotes.Size = new System.Drawing.Size(601, 64);
            this.rbnTxtNotes.StickyLabel = stickyLabel1;
            richEditBoxStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.rbnTxtNotes.Style = richEditBoxStyle1;
            this.rbnTxtNotes.TabIndex = 8;
            this.rbnTxtNotes.TextFormatted = "";
            this.rbnTxtNotes.Visible = false;
            this.rbnTxtNotes.TextChanged += new System.EventHandler(this.rbnTxtNotes_TextChanged);
            // 
            // proBarOpr
            // 
            this.proBarOpr.BackColor = System.Drawing.Color.Transparent;
            this.proBarOpr.Location = new System.Drawing.Point(11, 533);
            this.proBarOpr.Name = "proBarOpr";
            this.proBarOpr.Size = new System.Drawing.Size(601, 24);
            this.proBarOpr.TabIndex = 18;
            this.proBarOpr.Text = "Operation";
            this.proBarOpr.Value = 50;
            this.proBarOpr.Visible = false;
            // 
            // rbnCboSeriesID
            // 
            this.rbnCboSeriesID.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnCboSeriesID.Location = new System.Drawing.Point(403, 101);
            this.rbnCboSeriesID.Name = "rbnCboSeriesID";
            this.rbnCboSeriesID.SelectedIndex = -1;
            this.rbnCboSeriesID.SelectedItem = null;
            this.rbnCboSeriesID.Size = new System.Drawing.Size(130, 22);
            this.rbnCboSeriesID.TabIndex = 1;
            this.rbnCboSeriesID.Text = "Select Series";
            this.rbnCboSeriesID.Visible = false;
            this.rbnCboSeriesID.SelectedIndexChanged += new System.EventHandler(this.rbnCboSeriesID_SelectedIndexChanged);
            // 
            // rbnTxtSeriesID
            // 
            this.rbnTxtSeriesID.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbnTxtSeriesID.Enabled = false;
            this.rbnTxtSeriesID.Location = new System.Drawing.Point(403, 101);
            this.rbnTxtSeriesID.Name = "rbnTxtSeriesID";
            this.rbnTxtSeriesID.Size = new System.Drawing.Size(130, 22);
            this.rbnTxtSeriesID.TabIndex = 3;
            // 
            // OFD
            // 
            this.OFD.FileName = "openFileDialog1";
            this.OFD.Multiselect = true;
            // 
            // frmSeriesControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 604);
            this.Controls.Add(this.rbnFrmSerControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSeriesControl";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[Opr] Series";
            this.Load += new System.EventHandler(this.frmSeriesControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.rbnFrmSerControl)).EndInit();
            this.rbnFrmSerControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonScrollablePanel1)).EndInit();
            this.ribbonPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lblSeriesID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPatiant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mListCats)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLstSerImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rbnTxtNotes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PureComponents.ActionSet.RibbonUI.RibbonForm rbnFrmSerControl;
        private PureComponents.ActionSet.RibbonUI.RibbonScrollablePanel ribbonScrollablePanel1;
        private PureComponents.ActionSet.RibbonUI.RibbonPanel ribbonPanel1;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnCancel;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnDone;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnDelAll;
        private PureComponents.ActionSet.RibbonUI.RibbonTextBox rbnTxtSeriesID;
        private PureComponents.EntrySet.Controls.Label lblSeriesID;
        private PureComponents.EntrySet.Controls.Label lblPatiant;
        private PureComponents.EntrySet.Lists.MultiList mListCats;
        private PureComponents.ActionSet.RibbonUI.RibbonComboBox rbnCboSeriesID;
        private PureComponents.ActionSet.RibbonUI.RibbonComboBox rbnCboPatiant;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnManipulate;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnNotes;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnRemoveImage;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnAddImage;
        private PureComponents.EntrySet.Lists.PictureList picLstSerImage;
        private System.Windows.Forms.PictureBox picQView;
        private PureComponents.EntrySet.Controls.RichEditBox rbnTxtNotes;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnTemp;
        private System.Windows.Forms.OpenFileDialog OFD;
        private PureComponents.EntrySet.Controls.SystemProgressBar proBarOpr;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnUnremove;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnAddCat;
        private PureComponents.ActionSet.RibbonUI.RibbonButton rbnBtnAddPat;
    }
}