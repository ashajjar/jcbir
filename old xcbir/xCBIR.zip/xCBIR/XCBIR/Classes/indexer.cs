using System;
using System.Collections.Generic;
using System.Text;

namespace XCBIR.Classes
{
    /// <summary>
    /// Holds indexing and filtering operations
    /// </summary>
    public class indexer
    {
    }
}
