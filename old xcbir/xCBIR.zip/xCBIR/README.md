xcbir
=====

Content-Based Image Retrieval (CBIR) for brain CT scans
