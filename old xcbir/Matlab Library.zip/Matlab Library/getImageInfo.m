function info=getImageInfo(imgPath)
info=imfinfo(imgPath);