/*
* MATLAB Compiler: 4.6 (R2007a)
* Date: Fri Jan 30 17:03:12 2009
* Arguments: "-B" "macro_default" "-W"
* "dotnet:ImageManipulation,ImageManipulationclass,0.0,private" "-d" "C:\Documents and
* Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_22.01.2009\Manipulation\ImageManipulation\src" "-T" "link:lib"
* "-v" "class{ImageManipulationclass:C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_22.01.2009\Manipulation\contrast.m,C:\Documents and
* Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_22.01.2009\Manipulation\BrightenImage.m}" 
*/

using System;
using System.Reflection;

using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;


[assembly: System.Reflection.AssemblyVersion("0.0.*")]
#if SHARED
[assembly: System.Reflection.AssemblyKeyFile(@"")]
#endif

namespace ImageManipulation
{
  /// <summary>
  /// The ImageManipulationclass class provides a CLS compliant interface to the
  /// M-functions contained in the files:
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My
  /// Documents\MATLAB\Project_22.01.2009\Manipulation\contrast.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My
  /// Documents\MATLAB\Project_22.01.2009\Manipulation\BrightenImage.m
  /// <newpara></newpara>
  /// matlabrc.m
  /// <newpara></newpara>
  /// dirname.m
  /// <newpara></newpara>
  /// deployprint.m
  /// <newpara></newpara>
  /// printdlg.m
  /// </summary>
  /// <remarks>
  /// @Version 0.0
  /// </remarks>
  public class ImageManipulationclass : IDisposable
    {
      #region Constructors

      /// <summary internal= "true">
      /// The static constructor instantiates and initializes the MATLAB Common Runtime
      /// instance.
      /// </summary>
      static ImageManipulationclass()
        {
          Assembly assembly= Assembly.GetExecutingAssembly();

          string ctfFilePath= assembly.Location;

          int lastDelimeter= ctfFilePath.LastIndexOf(@"\");

          ctfFilePath= ctfFilePath.Remove(lastDelimeter, (ctfFilePath.Length - lastDelimeter));

          if (MWMCR.InitializeApplication(new string[]{}))
            {
              mcr= new MWMCR(MCRComponentState.MCC_ImageManipulation_name_data,
                             MCRComponentState.MCC_ImageManipulation_root_data,
                             MCRComponentState.MCC_ImageManipulation_public_data,
                             MCRComponentState.MCC_ImageManipulation_session_data,
                             MCRComponentState.MCC_ImageManipulation_matlabpath_data,
                             MCRComponentState.MCC_ImageManipulation_classpath_data,
                             MCRComponentState.MCC_ImageManipulation_libpath_data,
                             MCRComponentState.MCC_ImageManipulation_mcr_application_options,
                             MCRComponentState.MCC_ImageManipulation_mcr_runtime_options,
                             MCRComponentState.MCC_ImageManipulation_mcr_pref_dir,
                             MCRComponentState.MCC_ImageManipulation_set_warning_state,
                             ctfFilePath, true);
            }
        }


      /// <summary>
      /// Constructs a new instance of the ImageManipulationclass class.
      /// </summary>
      public ImageManipulationclass()
        {
        }


      #endregion Constructors

      #region Finalize

      /// <summary internal= "true">
      /// Class destructor called by the CLR garbage collector.
      /// </summary>
      ~ImageManipulationclass()
        {
          Dispose(false);
        }


      /// <summary>
      /// Frees the native resources associated with this object
      /// </summary>
      public void Dispose()
        {
          Dispose(true);

          GC.SuppressFinalize(this);
        }


      /// <summary internal= "true">
      /// Internal dispose function
      /// </summary>
      protected virtual void Dispose(bool disposing)
        {
          if (!disposed)
            {
              disposed= true;

              if (disposing)
                {
                  // Free managed resources;
                }

              // Free native resources
            }
        }


      #endregion Finalize

      #region Methods

      /// <summary>
      /// Provides a single output, 0-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray contrast()
        {
          return mcr.EvaluateFunction("contrast");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray contrast(MWArray imgPath)
        {
          return mcr.EvaluateFunction("contrast", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="c">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray contrast(MWArray imgPath, MWArray c)
        {
          return mcr.EvaluateFunction("contrast", imgPath, c);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] contrast(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "contrast");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] contrast(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "contrast", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the contrast M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="c">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] contrast(int numArgsOut, MWArray imgPath, MWArray c)
        {
          return mcr.EvaluateFunction(numArgsOut, "contrast", imgPath, c);
        }


      /// <summary>
      /// Provides an interface for the contrast function in which the input and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void contrast(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("contrast", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray BrightenImage()
        {
          return mcr.EvaluateFunction("BrightenImage");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray BrightenImage(MWArray imgPath)
        {
          return mcr.EvaluateFunction("BrightenImage", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="Beta">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray BrightenImage(MWArray imgPath, MWArray Beta)
        {
          return mcr.EvaluateFunction("BrightenImage", imgPath, Beta);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] BrightenImage(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "BrightenImage");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] BrightenImage(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "BrightenImage", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the BrightenImage M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="Beta">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] BrightenImage(int numArgsOut, MWArray imgPath, MWArray Beta)
        {
          return mcr.EvaluateFunction(numArgsOut, "BrightenImage", imgPath, Beta);
        }


      /// <summary>
      /// Provides an interface for the BrightenImage function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image itself :
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void BrightenImage(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("BrightenImage", numArgsOut, ref argsOut, argsIn);
        }


      
      #endregion Methods

      #region Class Members

      private static MWMCR mcr= null;

      private bool disposed= false;

      #endregion Class Members
    }
}
