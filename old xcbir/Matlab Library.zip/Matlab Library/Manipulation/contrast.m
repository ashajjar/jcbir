function [W]=contrast(imgPath,c)
%Read image itself :
IMG=imread(imgPath);

[X Y] =size(size(IMG));
if((X*Y)>=3)
    IMG=rgb2gray(IMG);
end
[M N]=size(IMG);
W=zeros(M,N);

if((c+1)>=0)
    c=c+1;
else
    c=0;
end

for i=1:M
    for j=1:N
        W(i,j)=((double(IMG(i,j))-128)*c)+128;
        
        if(W(i,j)<0)
            W(i,j)=0;
        elseif(W(i,j)>=255)
            W(i,j)=255;
        end
    end
end

W=uint8(W);
