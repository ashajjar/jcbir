function [BImage]=BrightenImage(imgPath,Beta)
%Read image itself :
img=imread(imgPath);
%Read image file information :
IINFO=imfinfo(imgPath);
if (strcmp(IINFO.Format,'jpg')==1)
    if(IINFO.NumberOfSamples==3)
        img = rgb2gray(img);
    end
else
    img=img(:,:,1);
end

img = double(img);
BImage = brighten(img,Beta);
BImage=BImage.*255;
BImage=uint8(BImage);
%imwrite(BImage,imgPath,'jpg');