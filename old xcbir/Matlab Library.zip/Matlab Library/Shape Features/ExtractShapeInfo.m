function [Shape] = ExtractShapeInfo(imgPath, X, Y, Width, Hieght)
%ExtractShapeInfo : computes the shape information
%using central moment for an image img

% Read image
img=imread(imgPath);

S=size(size(img));
if(S(2)>2)
    % First of all convert image from 3-color to one-clor image
    img=rgb2gray(img);
end

% Crop image to brain
Cropped=zeros(Width,Hieght);
for i = 1 : Width
    for j = 1 : Hieght
        Cropped(i, j) = img((X+i-1),(Y+j-1));
    end
end

img = double(Cropped)./255;
% Toclaculate X0 and Y0:
M00=rawMoment(img,0,0);
M01=rawMoment(img,0,1);
M10=rawMoment(img,1,0);
X0=M10/M00;
Y0=M01/M00;

%Start calculating 
m1=M1(img,X0,Y0);
m2=M2(img,X0,Y0);
m3=M3(img,X0,Y0);
m4=M4(img,X0,Y0);
m5=M5(img,X0,Y0);
m6=M6(img,X0,Y0);
m7=M7(img,X0,Y0);
%Construct shape features vector
Shape=[m1 m2 m3 m4 m5 m6 m7];

%                                    _     _
%Calculates raw moments to calculate X and Y
function [rm] = rawMoment(img,i,j)
[x y]=size(img);
rm=0.0;
for k=1:x
    for l=1:y
        rm=rm+((k^i)*(l^j)*img(k,l));
    end
end

%Calculates central moments to calculate M1, M2, M3, M4, M5, M6 and M7
function [cm] = centralMoment(img,p,q,X0,Y0)
[x y]=size(img);
cm=0.0;
for i=1:x
    for j=1:y
        cm=cm+((i-X0)^p)*((j-Y0)^q)*img(i,j);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M1(img,X0,Y0)
u02=centralMoment(img,0,2,X0,Y0);
u20=centralMoment(img,2,0,X0,Y0);
m=u20+u02;

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M2(img,X0,Y0)
u02=centralMoment(img,0,2,X0,Y0);
u20=centralMoment(img,2,0,X0,Y0);
u11=centralMoment(img,1,1,X0,Y0);
m=(u20-u02)^2+u11^2;

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M3(img,X0,Y0)
u30=centralMoment(img,3,0,X0,Y0);
u12=centralMoment(img,1,2,X0,Y0);
u21=centralMoment(img,2,1,X0,Y0);
u03=centralMoment(img,0,3,X0,Y0);
m=(u30-3*u12)^2+(3*u21-u03)^2;

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M4(img,X0,Y0)
u30=centralMoment(img,3,0,X0,Y0);
u12=centralMoment(img,1,2,X0,Y0);
u21=centralMoment(img,2,1,X0,Y0);
u03=centralMoment(img,0,3,X0,Y0);
m=(u30+u12)^2+(u21+u03)^2;

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M5(img,X0,Y0)
u30=centralMoment(img,3,0,X0,Y0);
u12=centralMoment(img,1,2,X0,Y0);
u21=centralMoment(img,2,1,X0,Y0);
u03=centralMoment(img,0,3,X0,Y0);
m=(u30+u12)+(u30-3*u12)*(((u30+u12)^2)-3*((u21+u03)^2))+(3*u21-u03)*(u21+3*u03)*(3*((u03+u21)^2)-((u21-u03)^2));

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M6(img,X0,Y0)
u30=centralMoment(img,3,0,X0,Y0);
u12=centralMoment(img,1,2,X0,Y0);
u21=centralMoment(img,2,1,X0,Y0);
u03=centralMoment(img,0,3,X0,Y0);
u02=centralMoment(img,0,2,X0,Y0);
u20=centralMoment(img,2,0,X0,Y0);
u11=centralMoment(img,1,1,X0,Y0);
m=(u20+u02)*(((u30+u12)^2)-((u21+u03)^2))+(4*u11*(u30+u12)*(u21+u03));

%%%%%%%%%%%%%%%%%%%%%%%
function [m] = M7(img,X0,Y0)
u30=centralMoment(img,3,0,X0,Y0);
u12=centralMoment(img,1,2,X0,Y0);
u21=centralMoment(img,2,1,X0,Y0);
u03=centralMoment(img,0,3,X0,Y0);
m=(3*u21-u03)*(u30+u12)*(((u30+u12)^2)-3*((u21+u03)^2)) - (u30-3*u12)*(u21+u03)*(3*((u03+u21)^2)-((u21-u03)^2));
