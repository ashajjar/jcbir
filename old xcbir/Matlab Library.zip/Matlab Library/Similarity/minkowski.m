function dist=minkowski(A,B,o)
if (size(A)==size(B))
    dist=abs((sum((A-B).^o))^(1/o));
else
    dist=-1;
end