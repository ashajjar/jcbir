function he=histEntropy(imgPath, X, Y, Width, Hieght)
% Read image
img=imread(imgPath);

S=size(size(img));
if(S(2)>2)
    % First of all convert image from 3-color to one-clor image
    img=rgb2gray(img);
end

% Crop image to brain
Cropped=zeros(Width,Hieght);
for i = 1 : Width
    for j = 1 : Hieght
        Cropped(i, j) = img((X+i-1),(Y+j-1));
    end
end

% Calculate entropy for cropped image
he=entropy(Cropped);
