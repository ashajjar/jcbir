
imgpath='C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Brain\1\A (0).jpg';

t1=clock;
M=imageMean(imgpath);
display(sprintf(num2str(M)));
t2=clock;
display(t2-t1);

t3=clock;
hm=histMean(imgpath);
display(sprintf(num2str(hm)));
t4=clock;
display(t4-t3);