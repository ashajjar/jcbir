function []=TestImgFeature()
imgpathDef='C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Brain\1\A (XX).jpg';
for i=0:33
    I=num2str(i);
    imgpath=strrep(imgpathDef,'XX',I);
    M=imageMean(imgpath);
    SD=imageStdDev(imgpath);
    hm=histMean(imgpath);
    
    display(sprintf(num2str(i)));
    display(sprintf('Mean :'));
    display(sprintf(num2str(M)));
    display(sprintf('StdDev :'));
    display(sprintf(num2str(SD)));
    display(sprintf('Histogram Mean :'));
    display(sprintf(num2str(hm)));
    display('');
end

%i=5;
%imgpath='C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Brain\1\A (XX).jpg';
%I=num2str(i);
%imgpath=strrep(imgpath,'XX',I);
%M=imageMean(imgpath);
%display(sprintf(num2str(M)));
%display(imgpath);