imgpathDef='C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Brain\1\A (XX).jpg';

for i=0:33
    I=num2str(i);
    imgpath=strrep(imgpathDef,'XX',I);
    M=histEnergy(imgpath);
    display(sprintf(num2str(M)));
end