function hm=histMean(imgPath)
%Read image itself :
img=imread(imgPath);
%Read image file information :
IINFO=imfinfo(imgPath);
if (strcmp(IINFO.Format,'jpg')==1)
    if(IINFO.NumberOfSamples==3)
        img = rgb2gray(img);
    end
end
ih=imhist(img);
hm=0;
N=IINFO.Width *IINFO.Height;
for i=0:255
    hm=hm+((i+1)*ih(i+1)/N);
end
