function hv=histVariance(imgPath)
%Read image itself :
img=imread(imgPath);
%Read image file information :
IINFO=imfinfo(imgPath);
if (strcmp(IINFO.Format,'jpg')==1)
    if(IINFO.NumberOfSamples==3)
        img = rgb2gray(img);
    end
end
m=histMean(imgPath);
ih=imhist(img);
hv=0;
N=IINFO.Width *IINFO.Height;
for i=0:255
    hv=hv+(((i+1-m)^2)*ih(i+1)/N);
end
