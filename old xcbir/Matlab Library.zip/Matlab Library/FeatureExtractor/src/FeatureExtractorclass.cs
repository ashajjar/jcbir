/*
* MATLAB Compiler: 4.6 (R2007a)
* Date: Thu Jan 22 05:40:17 2009
* Arguments: "-B" "macro_default" "-W"
* "dotnet:FeatureExtractor,FeatureExtractorclass,0.0,private" "-d" "C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\FeatureExtractor\src" "-T"
* "link:lib" "-v" "class{FeatureExtractorclass:C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_20.01.2009\Color Features\histEnergy.m,C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
* Features\histEntropy.m,C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_20.01.2009\Color Features\imageMean.m,C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
* Features\imageMedian.m,C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_20.01.2009\Color Features\imageStdDev.m,C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Brian
* location\CropBrain.m,C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_20.01.2009\Shape Features\ExtractShapeInfo.m,C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Texture
* Feature\ExtractTextureInfo.m,C:\Documents and Settings\Ahmad Hajjar\My
* Documents\MATLAB\Project_20.01.2009\Similarity\minkowski.m,C:\Documents and
* Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\getImageInfo.m}" 
*/

using System;
using System.Reflection;

using MathWorks.MATLAB.NET.Arrays;
using MathWorks.MATLAB.NET.Utility;


[assembly: System.Reflection.AssemblyVersion("0.0.*")]
#if SHARED
[assembly: System.Reflection.AssemblyKeyFile(@"")]
#endif

namespace FeatureExtractor
{
  /// <summary>
  /// The FeatureExtractorclass class provides a CLS compliant interface to the
  /// M-functions contained in the files:
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
  /// Features\histEnergy.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
  /// Features\histEntropy.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
  /// Features\imageMean.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
  /// Features\imageMedian.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Color
  /// Features\imageStdDev.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Brian
  /// location\CropBrain.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My Documents\MATLAB\Project_20.01.2009\Shape
  /// Features\ExtractShapeInfo.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My
  /// Documents\MATLAB\Project_20.01.2009\Texture Feature\ExtractTextureInfo.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My
  /// Documents\MATLAB\Project_20.01.2009\Similarity\minkowski.m
  /// <newpara></newpara>
  /// C:\Documents and Settings\Ahmad Hajjar\My
  /// Documents\MATLAB\Project_20.01.2009\getImageInfo.m
  /// <newpara></newpara>
  /// matlabrc.m
  /// <newpara></newpara>
  /// dirname.m
  /// <newpara></newpara>
  /// deployprint.m
  /// <newpara></newpara>
  /// printdlg.m
  /// </summary>
  /// <remarks>
  /// @Version 0.0
  /// </remarks>
  public class FeatureExtractorclass : IDisposable
    {
      #region Constructors

      /// <summary internal= "true">
      /// The static constructor instantiates and initializes the MATLAB Common Runtime
      /// instance.
      /// </summary>
      static FeatureExtractorclass()
        {
          Assembly assembly= Assembly.GetExecutingAssembly();

          string ctfFilePath= assembly.Location;

          int lastDelimeter= ctfFilePath.LastIndexOf(@"\");

          ctfFilePath= ctfFilePath.Remove(lastDelimeter, (ctfFilePath.Length - lastDelimeter));

          if (MWMCR.InitializeApplication(new string[]{}))
            {
              mcr= new MWMCR(MCRComponentState.MCC_FeatureExtractor_name_data,
                             MCRComponentState.MCC_FeatureExtractor_root_data,
                             MCRComponentState.MCC_FeatureExtractor_public_data,
                             MCRComponentState.MCC_FeatureExtractor_session_data,
                             MCRComponentState.MCC_FeatureExtractor_matlabpath_data,
                             MCRComponentState.MCC_FeatureExtractor_classpath_data,
                             MCRComponentState.MCC_FeatureExtractor_libpath_data,
                             MCRComponentState.MCC_FeatureExtractor_mcr_application_options,
                             MCRComponentState.MCC_FeatureExtractor_mcr_runtime_options,
                             MCRComponentState.MCC_FeatureExtractor_mcr_pref_dir,
                             MCRComponentState.MCC_FeatureExtractor_set_warning_state,
                             ctfFilePath, true);
            }
        }


      /// <summary>
      /// Constructs a new instance of the FeatureExtractorclass class.
      /// </summary>
      public FeatureExtractorclass()
        {
        }


      #endregion Constructors

      #region Finalize

      /// <summary internal= "true">
      /// Class destructor called by the CLR garbage collector.
      /// </summary>
      ~FeatureExtractorclass()
        {
          Dispose(false);
        }


      /// <summary>
      /// Frees the native resources associated with this object
      /// </summary>
      public void Dispose()
        {
          Dispose(true);

          GC.SuppressFinalize(this);
        }


      /// <summary internal= "true">
      /// Internal dispose function
      /// </summary>
      protected virtual void Dispose(bool disposing)
        {
          if (!disposed)
            {
              disposed= true;

              if (disposing)
                {
                  // Free managed resources;
                }

              // Free native resources
            }
        }


      #endregion Finalize

      #region Methods

      /// <summary>
      /// Provides a single output, 0-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy()
        {
          return mcr.EvaluateFunction("histEnergy");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy(MWArray imgPath)
        {
          return mcr.EvaluateFunction("histEnergy", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("histEnergy", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("histEnergy", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy(MWArray imgPath, MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("histEnergy", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEnergy(MWArray imgPath, MWArray X, MWArray Y,
                                MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("histEnergy", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut, MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut, MWArray imgPath,
                                  MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the histEnergy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEnergy(int numArgsOut, MWArray imgPath, MWArray X,
                                  MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEnergy",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the histEnergy function in which the input and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void histEnergy(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("histEnergy", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy()
        {
          return mcr.EvaluateFunction("histEntropy");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy(MWArray imgPath)
        {
          return mcr.EvaluateFunction("histEntropy", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("histEntropy", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("histEntropy", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy(MWArray imgPath, MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("histEntropy", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray histEntropy(MWArray imgPath, MWArray X, MWArray Y,
                                 MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("histEntropy", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the histEntropy M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] histEntropy(int numArgsOut, MWArray imgPath, MWArray X,
                                   MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "histEntropy",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the histEntropy function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void histEntropy(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("histEntropy", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean()
        {
          return mcr.EvaluateFunction("imageMean");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean(MWArray imgPath)
        {
          return mcr.EvaluateFunction("imageMean", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("imageMean", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("imageMean", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean(MWArray imgPath, MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("imageMean", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMean(MWArray imgPath, MWArray X, MWArray Y,
                               MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("imageMean", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut, MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut, MWArray imgPath,
                                 MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the imageMean M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMean(int numArgsOut, MWArray imgPath, MWArray X,
                                 MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMean",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the imageMean function in which the input and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void imageMean(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("imageMean", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian()
        {
          return mcr.EvaluateFunction("imageMedian");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian(MWArray imgPath)
        {
          return mcr.EvaluateFunction("imageMedian", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("imageMedian", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("imageMedian", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian(MWArray imgPath, MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("imageMedian", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageMedian(MWArray imgPath, MWArray X, MWArray Y,
                                 MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("imageMedian", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the imageMedian M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageMedian(int numArgsOut, MWArray imgPath, MWArray X,
                                   MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageMedian",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the imageMedian function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void imageMedian(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("imageMedian", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev()
        {
          return mcr.EvaluateFunction("imageStdDev");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev(MWArray imgPath)
        {
          return mcr.EvaluateFunction("imageStdDev", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("imageStdDev", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("imageStdDev", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev(MWArray imgPath, MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("imageStdDev", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray imageStdDev(MWArray imgPath, MWArray X, MWArray Y,
                                 MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("imageStdDev", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut, MWArray imgPath,
                                   MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the imageStdDev M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] imageStdDev(int numArgsOut, MWArray imgPath, MWArray X,
                                   MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "imageStdDev",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the imageStdDev function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void imageStdDev(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("imageStdDev", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the CropBrain M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// BI is the image of the brain
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray CropBrain()
        {
          return mcr.EvaluateFunction("CropBrain");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the CropBrain M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// BI is the image of the brain
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray CropBrain(MWArray imgPath)
        {
          return mcr.EvaluateFunction("CropBrain", imgPath);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the CropBrain M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// BI is the image of the brain
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] CropBrain(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "CropBrain");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the CropBrain M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// BI is the image of the brain
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] CropBrain(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "CropBrain", imgPath);
        }


      /// <summary>
      /// Provides an interface for the CropBrain function in which the input and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// BI is the image of the brain
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void CropBrain(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("CropBrain", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo()
        {
          return mcr.EvaluateFunction("ExtractShapeInfo");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo(MWArray imgPath)
        {
          return mcr.EvaluateFunction("ExtractShapeInfo", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("ExtractShapeInfo", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("ExtractShapeInfo", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo(MWArray imgPath, MWArray X,
                                      MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("ExtractShapeInfo", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractShapeInfo(MWArray imgPath, MWArray X, MWArray Y,
                                      MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("ExtractShapeInfo", imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut, MWArray imgPath,
                                        MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut, MWArray imgPath,
                                        MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo",
                                      imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the ExtractShapeInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractShapeInfo(int numArgsOut, MWArray imgPath, MWArray X,
                                        MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractShapeInfo",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the ExtractShapeInfo function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// ExtractShapeInfo : computes the shape information
      /// using central moment for an image img
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void ExtractShapeInfo(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("ExtractShapeInfo", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo()
        {
          return mcr.EvaluateFunction("ExtractTextureInfo");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo(MWArray imgPath)
        {
          return mcr.EvaluateFunction("ExtractTextureInfo", imgPath);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo(MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction("ExtractTextureInfo", imgPath, X);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo(MWArray imgPath, MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction("ExtractTextureInfo", imgPath, X, Y);
        }


      /// <summary>
      /// Provides a single output, 4-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo(MWArray imgPath, MWArray X,
                                        MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction("ExtractTextureInfo", imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides a single output, 5-input interface to the ExtractTextureInfo
      /// M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray ExtractTextureInfo(MWArray imgPath, MWArray X, MWArray Y,
                                        MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction("ExtractTextureInfo", imgPath,
                                      X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo", imgPath);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut, MWArray imgPath, MWArray X)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo", imgPath, X);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut, MWArray imgPath,
                                          MWArray X, MWArray Y)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo", imgPath, X, Y);
        }


      /// <summary>
      /// Provides the standard 4-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut, MWArray imgPath,
                                          MWArray X, MWArray Y, MWArray Width)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo",
                                      imgPath, X, Y, Width);
        }


      /// <summary>
      /// Provides the standard 5-input interface to the ExtractTextureInfo M-function.
      /// </summary>
      /// <remarks>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <param name="X">Input argument #2</param>
      /// <param name="Y">Input argument #3</param>
      /// <param name="Width">Input argument #4</param>
      /// <param name="Hieght">Input argument #5</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] ExtractTextureInfo(int numArgsOut, MWArray imgPath, MWArray X,
                                          MWArray Y, MWArray Width, MWArray Hieght)
        {
          return mcr.EvaluateFunction(numArgsOut, "ExtractTextureInfo",
                                      imgPath, X, Y, Width, Hieght);
        }


      /// <summary>
      /// Provides an interface for the ExtractTextureInfo function in which the input
      /// and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// M-Documentation:
      /// Read image
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void ExtractTextureInfo(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("ExtractTextureInfo", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray minkowski()
        {
          return mcr.EvaluateFunction("minkowski");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="A">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray minkowski(MWArray A)
        {
          return mcr.EvaluateFunction("minkowski", A);
        }


      /// <summary>
      /// Provides a single output, 2-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="A">Input argument #1</param>
      /// <param name="B">Input argument #2</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray minkowski(MWArray A, MWArray B)
        {
          return mcr.EvaluateFunction("minkowski", A, B);
        }


      /// <summary>
      /// Provides a single output, 3-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="A">Input argument #1</param>
      /// <param name="B">Input argument #2</param>
      /// <param name="o">Input argument #3</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray minkowski(MWArray A, MWArray B, MWArray o)
        {
          return mcr.EvaluateFunction("minkowski", A, B, o);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] minkowski(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "minkowski");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="A">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] minkowski(int numArgsOut, MWArray A)
        {
          return mcr.EvaluateFunction(numArgsOut, "minkowski", A);
        }


      /// <summary>
      /// Provides the standard 2-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="A">Input argument #1</param>
      /// <param name="B">Input argument #2</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] minkowski(int numArgsOut, MWArray A, MWArray B)
        {
          return mcr.EvaluateFunction(numArgsOut, "minkowski", A, B);
        }


      /// <summary>
      /// Provides the standard 3-input interface to the minkowski M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="A">Input argument #1</param>
      /// <param name="B">Input argument #2</param>
      /// <param name="o">Input argument #3</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] minkowski(int numArgsOut, MWArray A, MWArray B, MWArray o)
        {
          return mcr.EvaluateFunction(numArgsOut, "minkowski", A, B, o);
        }


      /// <summary>
      /// Provides an interface for the minkowski function in which the input and output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void minkowski(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("minkowski", numArgsOut, ref argsOut, argsIn);
        }


      /// <summary>
      /// Provides a single output, 0-input interface to the getImageInfo M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray getImageInfo()
        {
          return mcr.EvaluateFunction("getImageInfo");
        }


      /// <summary>
      /// Provides a single output, 1-input interface to the getImageInfo M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An MWArray containing the first output argument.</returns>
      ///
      public MWArray getImageInfo(MWArray imgPath)
        {
          return mcr.EvaluateFunction("getImageInfo", imgPath);
        }


      /// <summary>
      /// Provides the standard 0-input interface to the getImageInfo M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] getImageInfo(int numArgsOut)
        {
          return mcr.EvaluateFunction(numArgsOut, "getImageInfo");
        }


      /// <summary>
      /// Provides the standard 1-input interface to the getImageInfo M-function.
      /// </summary>
      /// <remarks>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return.</param>
      /// <param name="imgPath">Input argument #1</param>
      /// <returns>An Array of length "numArgsOut" containing the output
      /// arguments.</returns>
      ///
      public MWArray[] getImageInfo(int numArgsOut, MWArray imgPath)
        {
          return mcr.EvaluateFunction(numArgsOut, "getImageInfo", imgPath);
        }


      /// <summary>
      /// Provides an interface for the getImageInfo function in which the input and
      /// output
      /// arguments are specified as an array of MWArrays.
      /// </summary>
      /// <remarks>
      /// This method will allocate and return by reference the output argument
      /// array.<newpara></newpara>
      /// </remarks>
      /// <param name="numArgsOut">The number of output arguments to return</param>
      /// <param name= "argsOut">Array of MWArray output arguments</param>
      /// <param name= "argsIn">Array of MWArray input arguments</param>
      ///
      public void getImageInfo(int numArgsOut, ref MWArray[] argsOut, MWArray[] argsIn)
        {
          mcr.EvaluateFunction("getImageInfo", numArgsOut, ref argsOut, argsIn);
        }


      
      #endregion Methods

      #region Class Members

      private static MWMCR mcr= null;

      private bool disposed= false;

      #endregion Class Members
    }
}
