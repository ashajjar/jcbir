function [B]= Cropping(A, X, Y, W, H)
for k = 1 : W
    for l = 1 : H
        B(k, l) = A((X+k), (Y+l));
    end
end
B=uint8(B);