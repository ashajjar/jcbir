function [minX minY cWidth cHieght]=CropBrain(imgPath)

% BI is the image of the brain
% Read image
BI=imread(imgPath);
S=size(size(BI));
if(S(2)>2)
    % First of all convert image from 3-color to one-clor image
    BI=rgb2gray(BI);
end
% Then determine brain edges
BW = edge(BI,'canny',0.9,5);
% Look for max and min for both X and Y
[H W]=size(BW);
xs=1;
ys=1;
for i=1:H
    for j=1:W
        if (BW(i,j)==1)
            X(xs)=i;
            Y(ys)=j;
            xs=xs+1;
            ys=ys+1;
        end
    end
end

minX=min(X);
maxX=max(X);

minY=min(Y);
maxY=max(Y);

%Cropping . . . .

cHieght=maxY-minY;
cWidth=maxX-minX;

for k = 1 : cWidth
    for l = 1 : cHieght
        Cropped(k, l) = BI((minX+k), (minY+l));
    end
end
imshow(Cropped)