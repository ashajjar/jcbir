function Texture=ExtractTextureInfo(imgPath, X, Y, Width, Hieght)
% Read image
img=imread(imgPath);

S=size(size(img));
if(S(2)>2)
    % First of all convert image from 3-color to one-clor image
    img=rgb2gray(img);
end

% Crop image to brain
Cropped=zeros(Width,Hieght);
for i = 1 : Width
    for j = 1 : Hieght
        Cropped(i, j) = img((X+i-1),(Y+j-1));
    end
end

%Calculate GLCM rank
x=max(max(Cropped))-min(min(Cropped))+1;
%Claculate GLCM for Direction = 0
D0=graycomatrix(Cropped,'NumLevels',x);
%Get the statistics for it . . . 
stats1 = graycoprops(D0);
E1=entropy(D0);
M1=max(max(D0));
%Construct the feature vector of it . . . 
Texture0=[stats1.Contrast stats1.Correlation stats1.Energy stats1.Homogeneity E1 M1];

%Claculate GLCM for Direction = 45
D45=graycomatrix(Cropped,'NumLevels',x,'offset',[-1 1]);
%Get the statistics for it . . . 
stats2 = graycoprops(D45);
E2=entropy(D45);
M2=max(max(D45));
%Construct the feature vector of it . . . 
Texture45=[stats2.Contrast stats2.Correlation stats2.Energy stats2.Homogeneity E2 M2];

%Claculate GLCM for Direction = 90
D90=graycomatrix(Cropped,'NumLevels',x,'offset',[-1 0]);
%Get the statistics for it . . . 
stats3 = graycoprops(D90);
E3=entropy(D90);
M3=max(max(D90));
%Construct the feature vector of it . . . 
Texture90=[stats3.Contrast stats3.Correlation stats3.Energy stats3.Homogeneity E3 M3];

%Claculate GLCM for Direction = 135
D135=graycomatrix(Cropped,'NumLevels',x,'offset',[-1 -1]);
%Get the statistics for it . . . 
stats4 = graycoprops(D135);
E4=entropy(D135);
M4=max(max(D135));
%Construct the feature vector of it . . . 
Texture135=[stats4.Contrast stats4.Correlation stats4.Energy stats4.Homogeneity E4 M4];

%Construct the feature vector of the whole image
Texture=[Texture0 Texture45 Texture90 Texture135];
